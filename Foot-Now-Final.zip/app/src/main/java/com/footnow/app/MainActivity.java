package com.footnow.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        webView.addJavascriptInterface(new ApiBridge(), "FootNowAndroid");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    public class ApiBridge {
        @JavascriptInterface
        public void getFixtures(final String from, final String to, final String key) {
            new Thread(() -> {
                String result;
                try {
                    String q = "?from=" + URLEncoder.encode(from, "UTF-8")
                            + "&to=" + URLEncoder.encode(to, "UTF-8")
                            + "&timezone=Africa%2FCairo";
                    URL url = new URL("https://v3.football.api-sports.io/fixtures" + q);
                    HttpURLConnection c = (HttpURLConnection) url.openConnection();
                    c.setRequestMethod("GET");
                    c.setRequestProperty("x-apisports-key", key);
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(20000);
                    int code = c.getResponseCode();
                    BufferedReader br = new BufferedReader(new InputStreamReader(
                            code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream()));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    result = sb.toString();
                    final int httpCode = code;
                    final String js = "window.onNativeFixtures(" + httpCode + "," +
                            org.json.JSONObject.quote(result) + ");";
                    runOnUiThread(() -> webView.evaluateJavascript(js, null));
                } catch (Exception e) {
                    final String msg = e.toString();
                    runOnUiThread(() -> webView.evaluateJavascript(
                            "window.onNativeFixtures(0," + org.json.JSONObject.quote("{\\\"errors\\\":[" + org.json.JSONObject.quote(msg) + "]}") + ");", null));
                }
            }).start();
        }
    }
}
